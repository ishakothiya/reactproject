import React, { useState } from 'react'
import { NavLink, Navigate, useNavigate } from 'react-router-dom'

function HOC(Component1) {
    const Newcomponent = (props) => {
        console.log(props)
   
        const navigate = useNavigate()
        // const  [login, setlogin] = useState(true)
        const logout = () => {
            localStorage.removeItem('islogin')
            props.setlogin(false)
            navigate('/login')
        }

        return <>
        <div className='d-flex' id='maindiv'>

        <div className='sidebar'>
               <div>
                    <h3 className='text-center'>Shop Me</h3>
               </div>
               <div>
               <ul className='list-unstyled menus px-2'>
                    <NavLink to='/dashboard'><li>Dashboard</li></NavLink>
                    <NavLink to='/Product'><li>Product</li></NavLink>
                    <NavLink to='/album'><li>Album</li></NavLink>
                    <NavLink to='/Recent_activity'><li>Recent_activity</li></NavLink>
               
                </ul>
               </div>
            </div>

        <div className='header'>
                <div className='d-flex p-2 justify-content-end headerdiv'>
                    <input type="text" placeholder='Search' />
                    <button className='btn ms-2' onClick={logout} type='button'>
                    LogOut
                    </button>
                  
                </div>
            
                <div>
                <Component1 {...props}/>
                </div>

            </div>
            

            
          
            
        </div>
        </>
    }
    return Newcomponent
}

export default HOC