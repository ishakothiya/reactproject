import React, { useEffect } from 'react'
import HOC from './HOC'
import { useDispatch, useSelector } from 'react-redux';
import { getproject } from '../Redux/Action/action';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import DataTable from 'react-data-table-component';

const Recent_activity = () => {

  let dispatch = useDispatch();
  let state = useSelector(store => store.api);

  
  useEffect(() => {
    dispatch(getproject())
  }, [])

  const col1 = [
    {
      id: 1,
      name: "albumId",
      selector: (row) => row.albumId
    },
    {
      id: 2,
      name: "albumName",
      selector: (row) => row.albumName
    }
  ];
  const col2 = [
    {
      id: 1,
      name: "licenceId",
      selector: (row) => row.licenceId
    },
    {
      id: 2,
      name: "licenceName",
      selector: (row) => row.licenceName
    }
  ];
  const col3 = [
    {
      id: 1,
      name: "singleId",
      selector: (row) => row.singleId
    },
    {
      id: 2,
      name: "songTitle",
      selector: (row) => row.songTitle
    }
  ];
  console.log(state);
  return (
    <>

        <>
      <div className='container'>
        <Tabs
          defaultActiveKey="profile"
          id="uncontrolled-tab-example"
          className="mb-3"
        >
          <Tab eventKey="albumsResponses" title="albumsResponses">
            <DataTable
              title="albums Responses"
              columns={col1}
              data={state.albumsResponses}
              defaultSortFieldId={1}
              pagination
            />
          </Tab>
          <Tab eventKey="licencesResponses" title="licencesResponses">
          <DataTable
              title="licences Responses"
              columns={col2}
              data={state.licencesResponses}
              defaultSortFieldId={1}
              pagination
            />
          </Tab>
          <Tab eventKey="singlesResponses" title="singlesResponses">
          <DataTable
              title="singles Responses"
              columns={col3}
              data={state.singlesResponses}
              defaultSortFieldId={1}
              pagination
            />
          </Tab>
        </Tabs>
      </div>

    </>
        
    </>
  )
}

export default HOC(Recent_activity)