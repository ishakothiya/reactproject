
export const GETAPI ="GETAPI"

export const ADD = "ADD"

export const DELETE = "DELETE"